import random
import csv
import re
import opencc
converter = opencc.OpenCC('t2s.json')

def clean_chinese(text):

    text = re.sub(r'[^\w\s\u4e00-\u9fa5]', '', text)

    text = converter.convert(text)
    return text


def contains_english(text):
    return bool(re.search(r'[a-zA-Z]', text))

def read_pairs(src_file, tgt_file):
    pairs = []
    with open(src_file, "r", encoding="utf-8") as src_f, open(tgt_file, "r", encoding="utf-8") as tgt_f:
        for src_line, tgt_line in zip(src_f, tgt_f):
            src = clean_chinese(src_line.strip())
            tgt = tgt_line.strip()

            if not src or contains_english(src) or not tgt:
                continue
            pairs.append((src, tgt))
    return pairs


def filter_pairs(pairs, min_len=15, max_len=30):
    return [(src, tgt) for src, tgt in pairs if min_len <= len(src) <= max_len]


def sample_pairs(pairs, n=1000, seed=42):
    random.seed(seed)
    return random.sample(pairs, min(n, len(pairs)))

def save_to_csv(path, pairs):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
        writer.writerow(["src", "ref"])
        for src, ref in pairs:
            writer.writerow([src, ref])


def main():

    src_file = r"CCMatrix.he-zh.zh"
    tgt_file = r"CCMatrix.he-zh.he"
    out_file = r"zh_he.csv"

    pairs = read_pairs(src_file, tgt_file)
    filtered_pairs = filter_pairs(pairs)

    sampled_pairs = sample_pairs(filtered_pairs)
    save_to_csv(out_file, sampled_pairs)
    print(f"保存了 {len(sampled_pairs)} 条数据到 {out_file}")

if __name__ == "__main__":
    main()
