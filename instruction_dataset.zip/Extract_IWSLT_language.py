import pandas as pd
import re
IN_PATH = r"IWSLT\ted_he-zh.tsv"
OUT_PATH = r"IWSLT\zh_he.csv" 

MIN_LEN = 20
MAX_LEN = 40
SAMPLE_N = 1000
SEED = 42


def zh_len_no_space(s: str) -> int:
    return len(re.sub(r"\s+", "", str(s)))


def main():
    df = pd.read_csv(
        IN_PATH,
        sep="\t",
        engine="python",
        header=0,
        usecols=[1, 2],
        on_bad_lines="skip"
    )

    df.columns = ["id_trans", "zh"]


    df = df.dropna(subset=["zh", "id_trans"])
    df["zh"] = df["zh"].astype(str).str.strip()
    df["id_trans"] = df["id_trans"].astype(str).str.strip()


    mask = df["zh"].apply(zh_len_no_space).between(MIN_LEN, MAX_LEN)
    df = df[mask]

    if len(df) > SAMPLE_N:
        df = df.sample(n=SAMPLE_N, random_state=SEED)

    out_df = df[["zh", "id_trans"]]
    out_df.to_csv(
        OUT_PATH,
        index=False,
        header=False,
        encoding="utf-8"
    )

    print(f"写出 {len(out_df)} 条到: {OUT_PATH}")

if __name__ == "__main__":
    main()
