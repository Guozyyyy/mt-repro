# -*- coding: utf-8 -*-
import os
import json
import math
from typing import List, Dict, Any

import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from transformers import (
    AutoConfig,
    AutoTokenizer,
    AutoModelForCausalLM,
    get_linear_schedule_with_warmup,
)
from peft import LoraConfig, get_peft_model
from tqdm.auto import tqdm

MODEL_PATH = "Qwen3-32B"

TRAIN_FILE = "refine_zh_ug_instruction_score.json"

ALPHA = 0.1
GAMMA = 0.6

OUTPUT_DIR = f"qwen32b_zh_ug_lora_weighted_gamma{GAMMA:.2f}"

# 训练超参
MAX_SEQ_LEN = 1024
BATCH_SIZE = 2
NUM_EPOCHS = 6
LEARNING_RATE = 1e-4
WEIGHT_DECAY = 0.01
WARMUP_RATIO = 0.03
GRAD_ACCUM_STEPS = 8
LOGGING_STEPS = 10
SAVE_STEPS = 1000
MAX_GRAD_NORM = 1.0

# LoRA 超参
LORA_R = 32
LORA_ALPHA = 64
LORA_DROPOUT = 0.05


EARLY_STOP_LOSS_THRESHOLD = 0.22
EARLY_STOP_MIN_IMPROVEMENT = 5e-4
EARLY_STOP_PATIENCE_LOGS = 40

WEIGHT_MIN = 0.5
WEIGHT_MAX = 1.5

NORMALIZE_WEIGHTS_IN_BATCH = True

PROMPT_TEMPLATE = (
    "你是一个精通中文和维吾尔语的专业翻译助手。\n"
    "任务：将给定的【中文句子】翻译为【维吾尔语】。\n"
    "要求：语气自然、表达地道，保持原意准确，疑问句要符合维吾尔语习惯。\n\n"
    "指令：{instruction}\n"
    "中文：{input}\n"
    "维吾尔语："
)



class ZhUgInstructionDataset(Dataset):

    def __init__(self, path: str):
        super().__init__()

        # 兜底：处理你之前遇到的 scored/score 文件名差异
        if not os.path.exists(path):
            alt1 = path.replace("_scored.json", "_score.json")
            alt2 = path.replace("_score.json", "_scored.json")
            if os.path.exists(alt1):
                print(f"[WARN] TRAIN_FILE not found, fallback to: {alt1}")
                path = alt1
            elif os.path.exists(alt2):
                print(f"[WARN] TRAIN_FILE not found, fallback to: {alt2}")
                path = alt2
            else:
                raise AssertionError(f"File not found: {path} (also tried {alt1} / {alt2})")

        self.path = path
        self.data: List[Dict[str, Any]] = []

        with open(path, "r", encoding="utf-8") as f:
            head = f.read(2048)
            f.seek(0)
            stripped = head.lstrip()

            if stripped.startswith("[") or stripped.startswith("{"):
                tmp = json.load(f)
                if isinstance(tmp, dict) and "data" in tmp:
                    self.data = tmp["data"]
                elif isinstance(tmp, list):
                    self.data = tmp
                else:
                    self.data = [tmp]
            else:
                # JSONL
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    self.data.append(json.loads(line))

        print(f"[INFO] Loaded {len(self.data)} examples from {path}")

        w_list = [self._score_to_weight(ex) for ex in self.data[: min(len(self.data), 5000)]]
        if len(w_list) > 0:
            w_min = min(w_list)
            w_max = max(w_list)
            w_mean = sum(w_list) / len(w_list)
            print(f"[INFO] Weight stats (first {len(w_list)}): min={w_min:.4f}, mean={w_mean:.4f}, max={w_max:.4f}")
    def __len__(self):
        return len(self.data)
    @staticmethod
    def _score_to_weight(ex: Dict[str, Any]) -> float:
        sc = ex.get("score_xyz_0_100", None)
        if not isinstance(sc, dict):
            return 1.0

        try:
            x = float(sc.get("x", 0))
            y = float(sc.get("y", 0))
            z = float(sc.get("z", 0))
        except Exception:
            return 1.0
        S = ALPHA * x + (1.0 - GAMMA) * y + GAMMA * z

        S = max(0.0, min(100.0, S))

        w = WEIGHT_MIN + (WEIGHT_MAX - WEIGHT_MIN) * (S / 100.0)
        return float(w)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        ex = self.data[idx]
        instruction = ex.get("instruction", "")
        _input = ex.get("input", "")
        output = ex.get("output", "")
        weight = self._score_to_weight(ex)
        return {
            "instruction": instruction,
            "input": _input,
            "output": output,
            "weight": weight,
        }


def build_prompt(instruction: str, _input: str) -> str:
    return PROMPT_TEMPLATE.format(instruction=instruction, input=_input)


def collate_fn(
    batch: List[Dict[str, Any]],
    tokenizer,
    max_seq_len: int = 1024,
) -> Dict[str, torch.Tensor]:

    input_ids_list = []
    labels_list = []
    weights_list = []

    for ex in batch:
        instruction = ex["instruction"]
        _input = ex["input"]
        output = ex["output"]
        weight = float(ex.get("weight", 1.0))
        weights_list.append(weight)

        prompt = build_prompt(instruction, _input)

        prompt_ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
        target_text = output + tokenizer.eos_token
        target_ids = tokenizer(target_text, add_special_tokens=False)["input_ids"]

        input_ids = prompt_ids + target_ids
        if len(input_ids) > max_seq_len:
            input_ids = input_ids[-max_seq_len:]
            full_labels = [-100] * len(prompt_ids) + target_ids
            full_labels = full_labels[-max_seq_len:]
        else:
            full_labels = [-100] * len(prompt_ids) + target_ids

        input_ids_list.append(torch.tensor(input_ids, dtype=torch.long))
        labels_list.append(torch.tensor(full_labels, dtype=torch.long))

    batch_max_len = max(t.size(0) for t in input_ids_list)
    pad_id = tokenizer.pad_token_id

    input_ids_padded = []
    labels_padded = []
    attention_mask = []

    for ids, lbs in zip(input_ids_list, labels_list):
        pad_len = batch_max_len - ids.size(0)
        input_ids_padded.append(torch.cat([ids, torch.full((pad_len,), pad_id, dtype=torch.long)]))
        labels_padded.append(torch.cat([lbs, torch.full((pad_len,), -100, dtype=torch.long)]))
        attention_mask.append(torch.cat([torch.ones_like(ids), torch.zeros((pad_len,), dtype=torch.long)]))

    return {
        "input_ids": torch.stack(input_ids_padded, dim=0),
        "labels": torch.stack(labels_padded, dim=0),
        "attention_mask": torch.stack(attention_mask, dim=0),
        "weights": torch.tensor(weights_list, dtype=torch.float32),
    }

def build_layerwise_device_map(num_layers: int, n_gpus: int) -> Dict[str, int]:
    assert n_gpus >= 1, "需要至少 1 张 GPU"
    device_map: Dict[str, int] = {}

    device_map["model.embed_tokens"] = 0

    layers_per_gpu = math.ceil(num_layers / n_gpus)
    for layer_idx in range(num_layers):
        dev_id = min(layer_idx // layers_per_gpu, n_gpus - 1)
        device_map[f"model.layers.{layer_idx}"] = dev_id

    last_dev = n_gpus - 1
    device_map["model.norm"] = last_dev
    device_map["lm_head"] = last_dev
    return device_map


def weighted_lm_loss(logits: torch.Tensor, labels: torch.Tensor, weights: torch.Tensor) -> torch.Tensor:

    # shift for causal LM
    shift_logits = logits[:, :-1, :].contiguous()
    shift_labels = labels[:, 1:].contiguous()

    dev = shift_logits.device
    shift_labels = shift_labels.to(dev)
    weights = weights.to(dev)

    mask = (shift_labels != -100).to(dev)

    token_loss = F.cross_entropy(
        shift_logits.transpose(1, 2),
        shift_labels,
        reduction="none",
    )

    token_loss = token_loss * mask
    denom = mask.sum(dim=1).clamp_min(1.0)
    seq_loss = token_loss.sum(dim=1) / denom

    if NORMALIZE_WEIGHTS_IN_BATCH:
        w_mean = weights.mean().clamp_min(1e-6)
        weights = weights / w_mean

    return (seq_loss * weights).mean()


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print(f"[INFO] MODEL_PATH = {MODEL_PATH}")
    print(f"[INFO] TRAIN_FILE = {TRAIN_FILE}")
    print(f"[INFO] OUTPUT_DIR = {OUTPUT_DIR}")
    print(f"[INFO] NUM_EPOCHS = {NUM_EPOCHS}, LoRA r = {LORA_R}, alpha = {LORA_ALPHA}")
    print(f"[INFO] EARLY_STOP_LOSS_THRESHOLD = {EARLY_STOP_LOSS_THRESHOLD}")
    print(f"[INFO] EARLY_STOP_MIN_IMPROVEMENT = {EARLY_STOP_MIN_IMPROVEMENT}")
    print(f"[INFO] EARLY_STOP_PATIENCE_LOGS = {EARLY_STOP_PATIENCE_LOGS}")

    print("[INFO] SCORE WEIGHT FORMULA:")
    print(f"       S = {ALPHA:.2f}*X + (1-{GAMMA:.2f})*Y + {GAMMA:.2f}*Z")
    print(f"[INFO] w∈[{WEIGHT_MIN},{WEIGHT_MAX}]  normalize_in_batch={NORMALIZE_WEIGHTS_IN_BATCH}")

    n_gpus = torch.cuda.device_count()
    if n_gpus == 0:
        raise RuntimeError("没有检测到 GPU，请检查 CUDA_VISIBLE_DEVICES 设置。")
    print(f"[INFO] Detected {n_gpus} visible CUDA device(s).")

    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    config = AutoConfig.from_pretrained(MODEL_PATH, trust_remote_code=True)
    if hasattr(config, "num_hidden_layers"):
        num_layers = config.num_hidden_layers
    elif hasattr(config, "n_layer"):
        num_layers = config.n_layer
    else:
        raise ValueError("找不到 Qwen3 config 中的层数字段（num_hidden_layers / n_layer）。")

    print(f"[INFO] Qwen3-32B has {num_layers} transformer layers.")

    dev_map = build_layerwise_device_map(num_layers, n_gpus)
    print("[INFO] Custom device_map (layer -> device):")
    for k, v in dev_map.items():
        print(f"  {k} -> cuda:{v}")

    print("[INFO] Loading base model with custom device_map ...")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        torch_dtype=torch.bfloat16,
        device_map=dev_map,
        trust_remote_code=True,
    )

    model.gradient_checkpointing_enable()
    if hasattr(model.config, "use_cache"):
        model.config.use_cache = False

    lora_config = LoraConfig(
        r=LORA_R,
        lora_alpha=LORA_ALPHA,
        lora_dropout=LORA_DROPOUT,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ],
    )
    model = get_peft_model(model, lora_config)

    if hasattr(model, "enable_input_require_grads"):
        model.enable_input_require_grads()

    model.print_trainable_parameters()
    model.train()

    first_device = next(model.parameters()).device
    print(f"[INFO] Model is sharded; first parameter device = {first_device}")

    train_dataset = ZhUgInstructionDataset(TRAIN_FILE)
    train_dataloader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        collate_fn=lambda b: collate_fn(b, tokenizer, MAX_SEQ_LEN),
    )

    num_update_steps_per_epoch = math.ceil(len(train_dataloader) / GRAD_ACCUM_STEPS)
    max_train_steps = num_update_steps_per_epoch * NUM_EPOCHS

    no_decay = ["bias", "LayerNorm.weight"]
    optimizer_grouped_params = [
        {
            "params": [
                p for n, p in model.named_parameters()
                if not any(nd in n for nd in no_decay) and p.requires_grad
            ],
            "weight_decay": WEIGHT_DECAY,
        },
        {
            "params": [
                p for n, p in model.named_parameters()
                if any(nd in n for nd in no_decay) and p.requires_grad
            ],
            "weight_decay": 0.0,
        },
    ]
    optimizer = torch.optim.AdamW(optimizer_grouped_params, lr=LEARNING_RATE)

    num_warmup_steps = int(WARMUP_RATIO * max_train_steps)
    lr_scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=num_warmup_steps,
        num_training_steps=max_train_steps,
    )

    progress_bar = tqdm(total=max_train_steps, desc="Training", unit="step")
    global_step = 0
    running_loss = 0.0

    best_loss = float("inf")
    no_improve_logs = 0
    stop_training = False

    for epoch in range(NUM_EPOCHS):
        print(f"[INFO] Epoch {epoch + 1}/{NUM_EPOCHS}")

        for step, batch in enumerate(train_dataloader):
            batch = {k: v.to(first_device) for k, v in batch.items()}

            outputs = model(
                input_ids=batch["input_ids"],
                attention_mask=batch["attention_mask"],
            )
            loss = weighted_lm_loss(outputs.logits, batch["labels"], batch["weights"])

            (loss / GRAD_ACCUM_STEPS).backward()
            running_loss += loss.item()

            if (step + 1) % GRAD_ACCUM_STEPS == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), MAX_GRAD_NORM)
                optimizer.step()
                lr_scheduler.step()
                optimizer.zero_grad()
                global_step += 1

                if global_step % LOGGING_STEPS == 0:
                    avg_loss = running_loss / LOGGING_STEPS
                    running_loss = 0.0
                    current_lr = lr_scheduler.get_last_lr()[0]
                    print(f"[STEP {global_step}] loss={avg_loss:.4f}, lr={current_lr:.6e}")
                    progress_bar.set_postfix({"loss": f"{avg_loss:.4f}"})

                    if avg_loss <= EARLY_STOP_LOSS_THRESHOLD:
                        print(f"[EARLY STOP] avg_loss={avg_loss:.4f} <= threshold={EARLY_STOP_LOSS_THRESHOLD:.4f}")
                        stop_training = True

                    if not stop_training:
                        if best_loss - avg_loss > EARLY_STOP_MIN_IMPROVEMENT:
                            best_loss = avg_loss
                            no_improve_logs = 0
                        else:
                            no_improve_logs += 1
                            print(f"[EARLY STOP] no significant improvement for {no_improve_logs} log(s) "
                                  f"(best={best_loss:.4f}, current={avg_loss:.4f}).")
                            if no_improve_logs >= EARLY_STOP_PATIENCE_LOGS:
                                print("[EARLY STOP] 达到 patience，提前停止。")
                                stop_training = True

                progress_bar.update(1)

                if global_step % SAVE_STEPS == 0:
                    ckpt_dir = os.path.join(OUTPUT_DIR, f"checkpoint-step{global_step}")
                    print(f"[INFO] Saving LoRA adapter to {ckpt_dir}")
                    model.save_pretrained(ckpt_dir)
                    tokenizer.save_pretrained(ckpt_dir)

                if stop_training:
                    break

        epoch_dir = os.path.join(OUTPUT_DIR, f"epoch-{epoch + 1}")
        print(f"[INFO] Saving LoRA adapter after epoch {epoch + 1} to {epoch_dir}")
        model.save_pretrained(epoch_dir)
        tokenizer.save_pretrained(epoch_dir)

        if stop_training:
            print("[INFO] Early stopping triggered; break out of epoch loop.")
            break

    progress_bar.close()

    final_path = os.path.join(OUTPUT_DIR, "final")
    print(f"[INFO] Training done. Saving final LoRA adapter to {final_path}")
    model.save_pretrained(final_path)
    tokenizer.save_pretrained(final_path)
if __name__ == "__main__":
    main()
