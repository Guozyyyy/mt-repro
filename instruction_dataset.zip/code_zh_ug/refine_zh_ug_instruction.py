import json
import re
from pathlib import Path
from typing import List, Dict
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

V1_PATH = Path("zh_ug_pool_refine_input.json")
V2_PATH = Path("zh_ug_pool_refine_instruction.json")
GEN_MODEL_PATH = "Qwen3-32B"

GEN_TOKENIZER = None
GEN_MODEL = None
GEN_EOS_ID = None

def _resolve_eos_id(tokenizer, model_config):
    eos_id = getattr(tokenizer, "eos_token_id", None)
    if eos_id is None:
        eos_id = getattr(model_config, "eos_token_id", None)
    if eos_id is None:
        eos_id = getattr(tokenizer, "pad_token_id", None)
    return eos_id


def load_qwen():
    global GEN_TOKENIZER, GEN_MODEL, GEN_EOS_ID

    print(">>> 正在加载 Qwen3-32B 作为 refine_instruction 模型 ...")
    GEN_TOKENIZER = AutoTokenizer.from_pretrained(
        GEN_MODEL_PATH,
        trust_remote_code=True
    )
    GEN_MODEL = AutoModelForCausalLM.from_pretrained(
        GEN_MODEL_PATH,
        torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        device_map="auto",
        trust_remote_code=True,
    )
    GEN_MODEL.eval()
    GEN_EOS_ID = _resolve_eos_id(GEN_TOKENIZER, GEN_MODEL.config)
    print(f">>> Qwen3-32B 加载完成, eos_token_id={GEN_EOS_ID}")


@torch.no_grad()
def gen_text(prompt: str, max_new_tokens: int = 128) -> str:

    device = getattr(GEN_MODEL, "device", None)
    if device is None:
        device = next(GEN_MODEL.parameters()).device

    inputs = GEN_TOKENIZER(prompt, return_tensors="pt").to(device)
    output_ids = GEN_MODEL.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        do_sample=False,
        eos_token_id=GEN_EOS_ID,
        pad_token_id=GEN_EOS_ID,
    )
    new_tokens = output_ids[0][inputs["input_ids"].shape[1]:]
    text = GEN_TOKENIZER.decode(new_tokens, skip_special_tokens=True)
    return text.strip()


def extract_json_field(raw_text: str, field_name: str) -> str:

    if not isinstance(raw_text, str):
        raise ValueError("raw_text 不是字符串")
    raw_text = raw_text.strip()
    m = re.search(r"\{.*?\}", raw_text, re.S)
    if not m:
        raise ValueError(f"未找到 JSON 对象。输出片段：{raw_text[:200]}")
    json_str = m.group(0)
    data = json.loads(json_str)
    if field_name not in data:
        raise KeyError(f"JSON 中缺少字段 {field_name}，JSON = {data}")
    return data[field_name]


def build_instruction_prompt(example: Dict) -> str:

    src_tgt = example.get("src->tgt", "zh->ug")
    orig_instr = example.get("instruction", "").strip()
    input_text = example.get("input", "").strip()

    max_len = 120
    if len(input_text) > max_len:
        excerpt = input_text[:max_len] + "……"
    else:
        excerpt = input_text

    prompt = f"""
你是一个翻译指导助手，帮助为机器翻译构造翻译指令。

现在有一条待翻译的中文句子，需要翻译成维吾尔语。请根据下面的中文段落，生成一条简洁且具有教学性质的翻译指令。根据输入文本的内容，自动判断适合的语气和表达方式，并生成符合以下要求的翻译指令：

1. 明确翻译的方向：中文 → 维吾尔语。
2. 根据输入文本的内容，并为翻译选择适合的语气和表达方式，不需要把文本的内容进行具体描述的，只说明翻译应该注意什么就可以。
3. 指令应简洁且具有指导性，帮助翻译模型理解文本的上下文，明确翻译的期望目标。
4. 指令字数控制在 30 字以内。
5. 输出必须是严格格式化的 JSON：只包含以下字段：
   {{ "refined_instruction": "..." }}
6. 不要输出额外的文字、解释或说明。

原句：
"{excerpt}"

请直接输出 JSON 格式的翻译指令，不要添加任何其他内容。
"""

    return prompt


def refine_instruction(example: Dict, max_retry: int = 2) -> str:
    orig_instr = example.get("instruction", "").strip() or "请将下面的中文句子翻译成目标语言。"
    last_error = None

    for attempt in range(max_retry):
        prompt = build_instruction_prompt(example)
        print(f"    [Qwen] 生成指令，第 {attempt + 1} 次尝试")
        raw = gen_text(prompt, max_new_tokens=128)
        print("    [Qwen] 完整输出：")
        print(raw)

        try:
            refined_instr = extract_json_field(raw, "refined_instruction").strip()
        except Exception as e:
            last_error = e
            print("    [WARN] 解析 refined_instruction 失败：", repr(e))
            continue
        if (refined_instr.startswith("“") and refined_instr.endswith("”")) or \
                (refined_instr.startswith("\"") and refined_instr.endswith("\"")):
            refined_instr = refined_instr[1:-1].strip()
        if not refined_instr:
            last_error = ValueError("refined_instruction 为空")
            print("    [WARN] refined_instruction 为空，重试。")
            continue
        if len(refined_instr) > 60:
            last_error = ValueError("refined_instruction 太长")
            print("    [WARN] refined_instruction 太长，重试。内容：", refined_instr)
            continue
        print("\n[原始指令]")
        print(orig_instr)
        print("\n[改进后的指令]")
        print(refined_instr)

        return refined_instr

    print("    [WARN] 多次生成 refined_instruction 失败，保留原指令。最后错误：", repr(last_error))
    return orig_instr


def main():
    if not V1_PATH.exists():
        raise FileNotFoundError(f"找不到输入文件: {V1_PATH}")
    print(f">>> 从 {V1_PATH} 读取数据 ...")
    with V1_PATH.open("r", encoding="utf-8") as f:
        data_v1: List[Dict] = json.load(f)
    print(f">>> 共 {len(data_v1)} 条样本。")
    load_qwen()
    new_data: List[Dict] = []
    for idx, ex in enumerate(data_v1, start=1):
        ex_id = ex.get("id", f"{idx:05d}")
        print("\n==================================================")
        print(f"=== 处理第 {idx} 条样本，id = {ex_id} ===")
        print("\n[原 instruction]")
        print(ex.get("instruction", ""))
        new_instr = refine_instruction(ex)
        print("\n[refine 后 instruction]")
        print(new_instr)
        new_ex = dict(ex)
        new_ex["instruction"] = new_instr
        new_data.append(new_ex)
        with V2_PATH.open("w", encoding="utf-8") as fw:
            json.dump(new_data, fw, ensure_ascii=False, indent=2)
        print(f"\n>>> 当前已写入 {len(new_data)} 条到 {V2_PATH}")
    print(f"\n>>> 全部完成，共 {len(new_data)} 条，结果保存在 {V2_PATH}")
if __name__ == "__main__":
    main()
