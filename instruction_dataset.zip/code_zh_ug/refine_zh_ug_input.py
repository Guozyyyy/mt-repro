import json
import re
from pathlib import Path
from typing import List, Dict
from collections import Counter

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

V0_PATH = Path("zh_ug_pool.json")
V1_PATH = Path("zh_ug_pool_refine_input.json")

GEN_MODEL_PATH = "Qwen3-32B"
TRANS_MODEL_PATH = "Hunyuan-MT-7B"

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

PLACEHOLDER_STRINGS = [
    "扩写后的完整中文段落",
    "这里是扩写后的完整中文段落",
    "他抬头望向灰蒙蒙的天空，心里既紧张又期待。",
]

GEN_TOKENIZER = None
GEN_MODEL = None
GEN_EOS_ID = None

TRANS_TOKENIZER = None
TRANS_MODEL = None
TRANS_EOS_ID = None

def _resolve_eos_id(tokenizer, model_config):
    eos_id = getattr(tokenizer, "eos_token_id", None)
    if eos_id is None:
        eos_id = getattr(model_config, "eos_token_id", None)
    if eos_id is None:
        eos_id = getattr(tokenizer, "pad_token_id", None)
    return eos_id
def load_models():
    global GEN_TOKENIZER, GEN_MODEL, GEN_EOS_ID
    global TRANS_TOKENIZER, TRANS_MODEL, TRANS_EOS_ID
    print(">>> 正在加载 Qwen3-32B 作为 refine_input 模型 ...")
    GEN_TOKENIZER = AutoTokenizer.from_pretrained(
        GEN_MODEL_PATH,
        trust_remote_code=True
    )
    GEN_MODEL = AutoModelForCausalLM.from_pretrained(
        GEN_MODEL_PATH,
        torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        device_map="auto",
        trust_remote_code=True,
    )
    GEN_MODEL.eval()
    GEN_EOS_ID = _resolve_eos_id(GEN_TOKENIZER, GEN_MODEL.config)
    print(f">>> Qwen3-32B 加载完成, eos_token_id={GEN_EOS_ID}")

    print(">>> 正在加载 Hunyuan-MT-7B 作为翻译模型 ...")
    TRANS_TOKENIZER = AutoTokenizer.from_pretrained(TRANS_MODEL_PATH)
    TRANS_MODEL = AutoModelForCausalLM.from_pretrained(
        TRANS_MODEL_PATH,
        torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
        device_map="auto",
    )
    TRANS_MODEL.eval()
    TRANS_EOS_ID = _resolve_eos_id(TRANS_TOKENIZER, TRANS_MODEL.config)
    print(f">>> Hunyuan-MT-7B 加载完成, eos_token_id={TRANS_EOS_ID}")
@torch.no_grad()
def gen_text(prompt: str, max_new_tokens: int = 256) -> str:

    inputs = GEN_TOKENIZER(prompt, return_tensors="pt").to(GEN_MODEL.device)
    output_ids = GEN_MODEL.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        do_sample=True,
        temperature=0.8,
        top_p=0.9,
        eos_token_id=GEN_EOS_ID,
        pad_token_id=GEN_EOS_ID,
    )
    new_tokens = output_ids[0][inputs["input_ids"].shape[1]:]
    text = GEN_TOKENIZER.decode(new_tokens, skip_special_tokens=True)
    return text.strip()


def extract_json_field(raw_text: str, field_name: str) -> str:

    if not isinstance(raw_text, str):
        raise ValueError("raw_text 不是字符串")
    raw_text = raw_text.strip()
    m = re.search(r"\{.*?\}", raw_text, re.S)
    if not m:
        raise ValueError(f"未找到 JSON 对象。输出片段：{raw_text[:200]}")
    json_str = m.group(0)
    data = json.loads(json_str)
    if field_name not in data:
        raise KeyError(f"JSON 中缺少字段 {field_name}，JSON = {data}")
    return data[field_name]

def build_refine_prompt(example: Dict, attempt: int = 0) -> str:

    src_tgt = example.get("src->tgt", "zh->ug")
    if "->" in src_tgt:
        src_lang, tgt_lang = src_tgt.split("->", 1)
    else:
        src_lang, tgt_lang = "zh", "ug"

    original_input = example["input"]

    forbid_line = ""
    if attempt >= 1:
        forbid_line = (
            "注意：不能把“扩写后的完整中文段落”或类似占位话，"
            "也不能只重复原句，必须写出新的 2～4 句中文小段落。\n"
        )

    prompt = f"""你是一个中文写作助手，正在为「{src_lang}→{tgt_lang}」翻译任务构造训练用的中文段落。

请根据下面的中文句子，扩写成 2～4 句的小段落，可以适当补充时间、地点、人物的简单背景或心理活动，但要保持原句的核心意思，不要引入相反的信息。扩写后的段落里要包含这句原话（可以做轻微改写）。

{forbid_line}输出要求：
1. 只用中文，不要外文。
2. 不要解释任务，不要自言自语。
3. 只输出一个 JSON 对象，格式严格为：{{"refined_input": "这里是扩写后的完整中文段落"}}。
4. 只允许输出一个 JSON 对象，不能输出多个备选答案。
5. 输出完这个 JSON 之后立刻停止生成，不要再写任何别的内容。

原句：
"{original_input}"

现在直接输出 JSON："""

    return prompt


def simple_fallback_refine(original_input: str) -> str:

    original_input = original_input.strip().rstrip("。！？!?")
    return (
        f"在一次日常的经历中，{original_input}。"
        f"这件事虽然看起来很普通，但对当事人来说却是一个小小的转折点。"
        f"每次回想起当时的情景，他都会有一些新的感受和思考。"
    )


def get_refined_input(example: Dict, max_retry: int = 3) -> str:

    original_input = example["input"].strip()
    last_error = None

    for attempt in range(max_retry):
        prompt = build_refine_prompt(example, attempt=attempt)
        print(f"    [Qwen] 第 {attempt+1} 次尝试")
        raw = gen_text(prompt, max_new_tokens=256)

        print("    [Qwen] 完整输出：")
        print(raw)

        try:
            refined = extract_json_field(raw, "refined_input").strip()
        except Exception as e:
            last_error = e
            print("    [WARN] 解析 refined_input 失败：", repr(e))
            continue

        if any(ph in refined for ph in PLACEHOLDER_STRINGS):
            last_error = ValueError("refined_input is placeholder-like")
            print("    [WARN] refined_input 包含占位词，重试。")
            continue

        if len(refined) <= len(original_input):
            last_error = ValueError("refined_input too short / not expanded")
            print("    [WARN] refined_input 看起来没怎么扩写，重试。")
            continue

        return refined

    print("    [WARN] 多次生成 refined_input 失败，改用通用模板扩写。最后错误：", repr(last_error))
    return simple_fallback_refine(original_input)
@torch.no_grad()
def translate_zh_to_ug(text: str, max_new_tokens: int = 1024) -> str:

    if not isinstance(text, str):
        return ""
    text = text.strip()
    if not text:
        return ""

    user_content = f"把下面的文本翻译成维吾尔语，不要额外解释。\n\n{text}"

    use_chat = hasattr(TRANS_TOKENIZER, "apply_chat_template")
    input_len = None

    if use_chat:
        messages = [{"role": "user", "content": user_content}]
        try:
            input_ids = TRANS_TOKENIZER.apply_chat_template(
                messages,
                tokenize=True,
                add_generation_prompt=True,
                return_tensors="pt",
            )
        except TypeError:
            input_ids = TRANS_TOKENIZER.apply_chat_template(
                messages,
                tokenize=True,
                return_tensors="pt",
            )
        input_ids = input_ids.to(TRANS_MODEL.device)
        input_len = input_ids.shape[1]
        gen_args = {"input_ids": input_ids}
    else:
        enc = TRANS_TOKENIZER(user_content, return_tensors="pt")
        enc = {k: v.to(TRANS_MODEL.device) for k, v in enc.items()}
        input_len = enc["input_ids"].shape[1]
        gen_args = enc

    pad_id = getattr(TRANS_TOKENIZER, "pad_token_id", None)
    if pad_id is None:
        pad_id = TRANS_EOS_ID

    if pad_id is not None:
        output_ids = TRANS_MODEL.generate(
            **gen_args,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=pad_id,
        )
    else:
        output_ids = TRANS_MODEL.generate(
            **gen_args,
            max_new_tokens=max_new_tokens,
            do_sample=False,
        )

    seq = output_ids[0]
    if input_len is not None and seq.shape[0] > input_len:
        new_tokens = seq[input_len:]
    else:
        new_tokens = seq

    out = TRANS_TOKENIZER.decode(new_tokens, skip_special_tokens=True)
    return out.strip()


def looks_bad_translation(new_output: str, old_output: str) -> bool:
    if not new_output:
        return True

    if old_output:
        if len(new_output) > max(1200, 5 * len(old_output)):
            return True
    else:
        if len(new_output) > 2000:
            return True

    chars = [ch for ch in new_output if not ch.isspace()]
    if not chars:
        return True
    counter = Counter(chars)
    most_char, most_count = counter.most_common(1)[0]
    if most_count / len(chars) > 0.7:
        return True

    return False


def main():
    if not V0_PATH.exists():
        raise FileNotFoundError(f"找不到原始文件: {V0_PATH}")

    print(f">>> 从 {V0_PATH} 读取原始数据 ...")
    with V0_PATH.open("r", encoding="utf-8") as f:
        data_v0: List[Dict] = json.load(f)

    print(f">>> 共 {len(data_v0)} 条样本。")

    load_models()

    new_data: List[Dict] = []

    for idx, ex in enumerate(data_v0, start=1):
        ex_id = ex.get("id", f"{idx:05d}")
        original_input = ex["input"].strip()

        print("\n==================================================")
        print(f"=== 处理第 {idx} 条样本，id = {ex_id} ===")

        print("\n[原始中文句子]")
        print(original_input)

        refined_input = get_refined_input(ex)
        print("\n[Qwen 扩写后的 refined_input]")
        print(refined_input)

        new_output = translate_zh_to_ug(refined_input)
        print("\n[Hunyuan 翻译后的 output]")
        print(new_output)

        old_output = ex.get("output", "")
        if looks_bad_translation(new_output, old_output):
            print("\n[WARN] 译文看起来异常，回退到 v0 的原始 output。")
            new_output = old_output

        new_ex = {
            "id": ex_id,
            "src->tgt": ex.get("src->tgt", "zh->ug"),
            "instruction": ex["instruction"],
            "input": refined_input,
            "output": new_output,
        }
        new_data.append(new_ex)

        with V1_PATH.open("w", encoding="utf-8") as fw:
            json.dump(new_data, fw, ensure_ascii=False, indent=2)
        print(f"\n>>> 当前已写入 {len(new_data)} 条到 {V1_PATH}")

    print(f"\n>>> 全部完成，共 {len(new_data)} 条，结果保存在 {V1_PATH}")


if __name__ == "__main__":
    main()
