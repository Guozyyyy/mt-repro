INPUT_JSON_A = "zh_ug_pool.json"          
INPUT_JSON_B = "refine_zh_ug_instruction.json"
OUTPUT_JSON_A = "zh_ug_pool_score.json"
OUTPUT_JSON_B = "refine_zh_ug_instruction_score.json"
MODEL_PATH = "Qwen3-14B"
MAX_NEW_TOKENS = 512
SAVE_EVERY = 1
PRINT_EACH = True
PRINT_RAW_ON_FAIL = True
RAW_PRINT_CHARS = 600
RESUME_FROM_OUTPUT = True
DISABLE_THINKING = True
import os
import json
import re
import argparse
from typing import Any, Dict, List, Optional, Tuple
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
THINK_BLOCK_RE = re.compile(r"<think>.*?</think>", re.S | re.I)
def _strip_code_fences(s: str) -> str:
    s = (s or "").strip()
    s = s.replace("```json", "```").replace("```JSON", "```").replace("```Json", "```")
    if "```" in s:
        parts = s.split("```")
        blocks = [parts[i].strip() for i in range(1, len(parts), 2)]
        if blocks:
            s = max(blocks, key=len)
    return s.strip()
def _remove_think_blocks(s: str) -> str:
    s = (s or "")
    s = THINK_BLOCK_RE.sub("", s)
    s = s.replace("<think>", "").replace("</think>", "")
    return s.strip()
def extract_first_json_object(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    text = _remove_think_blocks(_strip_code_fences(text))
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    start = text.find("{")
    if start < 0:
        return None
    in_str = False
    esc = False
    depth = 0
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    cand = text[start:i+1].strip()
                    cand2 = re.sub(r",\s*([}\]])", r"\1", cand)
                    try:
                        obj = json.loads(cand2)
                        if isinstance(obj, dict):
                            return obj
                    except Exception:
                        return None
    return None
def build_prompt(a: Optional[Dict[str, Any]], b: Optional[Dict[str, Any]]) -> str:
    def fmt(ex: Optional[Dict[str, Any]]) -> str:
        if ex is None:
            return (
                "id: <缺失>\n"
                "src->tgt: <缺失>\n"
                "instruction: <缺失>\n"
                "input: <缺失>\n"
                "output: <缺失>\n"
            )
        return (
            f"id: {ex.get('id','')}\n"
            f"src->tgt: {ex.get('src->tgt','')}\n"
            f"instruction: {ex.get('instruction','')}\n"
            f"input: {ex.get('input','')}\n"
            f"output: {ex.get('output','')}\n"
        )
    return f"""
/no_think
你是一名严格的「翻译指令数据」评审员。你会看到同一条任务的两个版本：版本A 与 版本B（id 相同）。
请对【每个版本】分别给三个整数分数，范围 0~100：
x = instruction 质量（指令清晰、具体、无歧义、约束合理）
y = input 质量（内容连贯、有信息量、与指令匹配、长度难度合理）
z = output 质量（译文流畅自然、翻译准确、满足风格/语气/细节要求、无明显漏译/错译/臆造）
极其重要：
1) 你必须只输出一个 JSON 对象，不能输出任何其它文字（不能解释、不能 markdown、不能前后缀）。
2) 必须可被 json.loads 解析（双引号、合法 JSON）。
3) 输出格式必须严格为：
   {{"A":{{"x":..,"y":..,"z":..}},"B":{{"x":..,"y":..,"z":..}}}}
示例（仅示例）：
{{"A":{{"x":80,"y":75,"z":90}},"B":{{"x":60,"y":50,"z":70}}}}
如果某个版本缺失，则该版本 x=y=z=0。
【版本A】
{fmt(a)}
【版本B】
{fmt(b)}
现在只输出 JSON：
""".strip()
def build_repair_prompt(raw_output: str) -> str:
    raw_output = (raw_output or "").strip()
    raw_output = raw_output[:2000]  # 防止太长
    return f"""
/no_think
你刚才没有按要求输出合法 JSON。现在请把“上一条输出”转换成严格合法 JSON：
只允许输出一个 JSON 对象，格式必须是：
{{"A":{{"x":0,"y":0,"z":0}},"B":{{"x":0,"y":0,"z":0}}}}
不要输出任何解释、不要 markdown、不要多余文字。
上一条输出如下：
{raw_output}
现在只输出 JSON：
""".strip()
def load_json_array(path: str) -> List[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError(f"期望 {path} 是 JSON 数组(list)")
    return data
def dump_json_array(path: str, data: List[Dict[str, Any]]) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)
def is_all_zero_score(sc: Any) -> bool:
    if not isinstance(sc, dict):
        return True
    return int(sc.get("x", 0)) == 0 and int(sc.get("y", 0)) == 0 and int(sc.get("z", 0)) == 0
def load_model(model_path: str):
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)

    dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
    try:
        model = AutoModelForCausalLM.from_pretrained(
            model_path,
            dtype=dtype,
            device_map="auto",
            trust_remote_code=True,
        )
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(
            model_path,
            torch_dtype=dtype,
            device_map="auto",
            trust_remote_code=True,
        )
    model.eval()
    if DISABLE_THINKING:
        for cfg in (model.config, getattr(model, "generation_config", None)):
            if cfg is not None and hasattr(cfg, "enable_thinking"):
                setattr(cfg, "enable_thinking", False)

    if getattr(tokenizer, "pad_token_id", None) is None and getattr(tokenizer, "eos_token_id", None) is not None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    return tokenizer, model
@torch.inference_mode()
def generate_text(model, tokenizer, prompt: str, max_new_tokens: int) -> str:
    if DISABLE_THINKING and not prompt.lstrip().startswith("/no_think"):
        prompt = "/no_think\n" + prompt
    messages = [
        {"role": "system", "content": "你是严谨评审员。禁止输出<think>。只能输出合法JSON。"},
        {"role": "user", "content": prompt},
    ]
    if hasattr(tokenizer, "apply_chat_template"):
        text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = tokenizer(text, return_tensors="pt").to(model.device)
    else:
        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    out = model.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        do_sample=False,
        eos_token_id=getattr(tokenizer, "eos_token_id", None),
        pad_token_id=getattr(tokenizer, "pad_token_id", None),
    )
    gen = out[0][inputs["input_ids"].shape[-1]:]
    decoded = tokenizer.decode(gen, skip_special_tokens=True)
    decoded = _remove_think_blocks(decoded)
    return decoded
def safe_scores(obj: Any) -> Dict[str, int]:
    if not isinstance(obj, dict):
        return {"x": 0, "y": 0, "z": 0}
    try:
        x = int(obj.get("x", 0))
        y = int(obj.get("y", 0))
        z = int(obj.get("z", 0))
    except Exception:
        return {"x": 0, "y": 0, "z": 0}
    return {
        "x": max(0, min(100, x)),
        "y": max(0, min(100, y)),
        "z": max(0, min(100, z)),
    }
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--file_a", type=str, default=INPUT_JSON_A)
    parser.add_argument("--file_b", type=str, default=INPUT_JSON_B)
    parser.add_argument("--out_a", type=str, default=OUTPUT_JSON_A)
    parser.add_argument("--out_b", type=str, default=OUTPUT_JSON_B)
    parser.add_argument("--model_path", type=str, default=MODEL_PATH)
    parser.add_argument("--max_new_tokens", type=int, default=MAX_NEW_TOKENS)
    parser.add_argument("--limit", type=int, default=-1)
    parser.add_argument("--start", type=int, default=0)
    args = parser.parse_args()
    data_a_in = load_json_array(args.file_a)
    data_b_in = load_json_array(args.file_b)
    out_a = [dict(x) for x in data_a_in]
    out_b = [dict(x) for x in data_b_in]
    idx_a = {str(x.get("id")): i for i, x in enumerate(out_a)}
    idx_b = {str(x.get("id")): i for i, x in enumerate(out_b)}
    all_ids = sorted(set(idx_a.keys()) | set(idx_b.keys()))
    if args.limit is not None and args.limit > 0:
        all_ids = all_ids[:args.limit]
    if args.start > 0:
        all_ids = all_ids[args.start:]
    if RESUME_FROM_OUTPUT:
        if os.path.exists(args.out_a):
            try:
                prev_a = load_json_array(args.out_a)
                prev_map = {str(x.get("id")): x for x in prev_a}
                for sid, i in idx_a.items():
                    if sid in prev_map and isinstance(prev_map[sid], dict):
                        if "score_xyz_0_100" in prev_map[sid]:
                            out_a[i]["score_xyz_0_100"] = prev_map[sid]["score_xyz_0_100"]
            except Exception:
                pass
        if os.path.exists(args.out_b):
            try:
                prev_b = load_json_array(args.out_b)
                prev_map = {str(x.get("id")): x for x in prev_b}
                for sid, i in idx_b.items():
                    if sid in prev_map and isinstance(prev_map[sid], dict):
                        if "score_xyz_0_100" in prev_map[sid]:
                            out_b[i]["score_xyz_0_100"] = prev_map[sid]["score_xyz_0_100"]
            except Exception:
                pass
    print(f"[INFO] 待评分 id 数 = {len(all_ids)}")
    print(f"[INFO] model_path = {args.model_path}")
    tokenizer, model = load_model(args.model_path)
    processed = 0
    for sid in all_ids:
        a = out_a[idx_a[sid]] if sid in idx_a else None
        b = out_b[idx_b[sid]] if sid in idx_b else None
        if RESUME_FROM_OUTPUT:
            a_sc = (a or {}).get("score_xyz_0_100")
            b_sc = (b or {}).get("score_xyz_0_100")
            a_done = (a is None) or (isinstance(a_sc, dict) and not is_all_zero_score(a_sc))
            b_done = (b is None) or (isinstance(b_sc, dict) and not is_all_zero_score(b_sc))
            if a_done and b_done:
                continue
        prompt = build_prompt(a, b)
        raw1 = generate_text(model, tokenizer, prompt, max_new_tokens=args.max_new_tokens)
        js = extract_first_json_object(raw1)

        if js is None or "A" not in js or "B" not in js:
            if PRINT_RAW_ON_FAIL:
                print(f"[WARN] 解析失败 id={sid}，模型原始输出前{RAW_PRINT_CHARS}字：\n{raw1[:RAW_PRINT_CHARS]}\n---")

            repair_prompt = build_repair_prompt(raw1)
            raw2 = generate_text(model, tokenizer, repair_prompt, max_new_tokens=256)
            js = extract_first_json_object(raw2)

            if (js is None or "A" not in js or "B" not in js) and PRINT_RAW_ON_FAIL:
                print(f"[WARN] 二次修复仍失败 id={sid}，输出前{RAW_PRINT_CHARS}字：\n{raw2[:RAW_PRINT_CHARS]}\n===")

        sc_a = safe_scores((js or {}).get("A"))
        sc_b = safe_scores((js or {}).get("B"))

        if a is not None:
            a["score_xyz_0_100"] = sc_a
        if b is not None:
            b["score_xyz_0_100"] = sc_b

        if PRINT_EACH:
            print(f'[SCORE] id={sid}  A {{"score_xyz_0_100": {sc_a}}}  |  B {{"score_xyz_0_100": {sc_b}}}')

        processed += 1

        if SAVE_EVERY > 0 and (processed % SAVE_EVERY == 0):
            dump_json_array(args.out_a, out_a)
            dump_json_array(args.out_b, out_b)

    dump_json_array(args.out_a, out_a)
    dump_json_array(args.out_b, out_b)

    print(f"[OK] 写出: {args.out_a} (n={len(out_a)})")
    print(f"[OK] 写出: {args.out_b} (n={len(out_b)})")


if __name__ == "__main__":
    main()
