import json
import random
import re
import unicodedata
from pathlib import Path
from typing import List, Dict
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

SEED_PATH = Path("zh_ug_seed.json")
POOL_PATH = Path("zh_ug_pool.json")

GEN_MODEL_PATH = "Qwen3-32B"
FILTER_MODEL_PATH = "Qwen3-4B-Instruct-2507"
TRANS_MODEL_PATH = "Hunyuan-MT-7B"

TARGET_SIZE = 5000
BATCH_SIZE = 4
DIRECTION = "zh->ug"

DEBUG_SHOW_RAW = True


ARABIC_CHAR_PATTERN = re.compile(
    r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]"
)


PROMPT1 = """你是一名精通中文的专业写作与任务设计助手。
你的任务不是直接翻译，而是**设计高质量的中文翻译任务原文**，后续会由一个独立的机器翻译模型自动把中文翻译成维吾尔语。
下面给出若干已经整理好的翻译指令样本（只展示指令和中文原文 input，它们组成一个合法的 JSON 数组）：
{examples_json}
请你先认真观察这些示例，学习它们的格式、句子长度和表达风格，然后在此基础上，生成恰好 {num_new} 条新的“中文翻译任务原文”。
基本格式：
1. 每条样本都是一个 JSON 对象，字段必须是："src->tgt", "instruction", "input" 三个字段。
2. "src->tgt" 固定为 "zh->ug"。
3. "instruction" 保持与示例相近的中文翻译指令风格，例如：
   - “请将下面的中文句子翻译成地道的维吾尔语。”
   - “把下面的话准确翻译成维吾尔语。”
4. "input" 是一句自然、具体、完整的中文句子，内容合理、语法正确、符合日常或专业语境。
5. **不要在 JSON 对象里包含 output 字段，也不要给出任何维吾尔语文本。**
多样性与创造性（在保证句子自然、合理前提下 think different）：
1. 在开始生成之前，请先在心里计划几种完全不同的场景、句式和语气类型（不要把计划过程写出来），然后根据这些计划去写句子 —— think different。
2. 句式不要全部是简单陈述句，可以混合使用：
   - 疑问句
   - 祈使句 / 请求句
   - 建议句
   - 感叹句
   - 带条件或因果关系的复句
3. 语气也要有变化，例如：
   - 礼貌请求、提醒、说明
   - 疑惑、担心、抱怨
   - 安慰、鼓励、道歉等
4. 场景可以自由想象，只要是现实生活中合理、自然的情境即可，不要局限于示例里的内容。
5. 每条 input 都要描述一个新的、可想象的具体情境；不要直接重复示例中的中文句子，也不要只改一两个字或只换一个词。
输出要求：
请直接输出一个 JSON 数组，数组中依次包含这 {num_new} 条新样本。形状大致类似：
[
  {{ "src->tgt": "zh->ug", "instruction": "...", "input": "..." }},
  {{ "src->tgt": "zh->ug", "instruction": "...", "input": "..." }}
]
不要输出任何解释、分析或思考过程，不要使用 Markdown，不要写出你“在心里计划了什么”。
只输出这个 JSON 数组本身。
"""

PROMPT_GEN_TEMPLATE = PROMPT1

PROMPT_FILTER_TEMPLATE = """你是一个审核助手，任务是判断一条“翻译指令样本”是否合格。

下面是一条样本的 JSON：
{sample_json}

请检查：
1. 是否是翻译任务：
   - instruction 是翻译指令；
   - src->tgt 为 "zh->ug"；
   - input 是中文句子；
   - output 是对应的维吾尔语翻译（阿拉伯文为主）。
2. 是否没有明显的暴力、色情、极端、仇恨、敏感政治内容。
3. 句子长度是否适中：input 和 output 各自的长度一般在 5 到 120 个字符之间。
4. 如果长度明显过短或过长，请判定为 REJECT。

如果这条样本合格，请只输出：OK
如果不合格，请只输出：REJECT

只输出 OK 或 REJECT，不要附加任何说明。
"""

def load_json(path: Path) -> List[Dict]:
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return []
    try:
        obj = json.loads(text)
        if isinstance(obj, list):
            return obj
        if isinstance(obj, dict):
            return [obj]
    except json.JSONDecodeError:
        pass

    decoder = json.JSONDecoder()
    idx = 0
    n = len(text)
    items: List[Dict] = []
    while idx < n:
        while idx < n and text[idx].isspace():
            idx += 1
        if idx >= n:
            break
        obj, end = decoder.raw_decode(text, idx)
        if isinstance(obj, list):
            items.extend([x for x in obj if isinstance(x, dict)])
        elif isinstance(obj, dict):
            items.append(obj)
        idx = end
    return items
def save_json(path: Path, data: List[Dict]):
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(path)

def extract_json_array(text: str):
    if not isinstance(text, str):
        return None
    text = text.strip()
    if not text:
        return None

    collected: List[Dict] = []

    obj_strs = re.findall(r"\{.*?\}", text, flags=re.S)
    for obj_str in obj_strs:
        try:
            obj = json.loads(obj_str)
        except Exception:
            continue
        if isinstance(obj, dict):
            collected.append(obj)
        elif isinstance(obj, list):
            for x in obj:
                if isinstance(x, dict):
                    collected.append(x)

    if collected:
        return collected
    try:
        obj = json.loads(text)
    except Exception:
        return None
    if isinstance(obj, dict):
        return [obj]
    if isinstance(obj, list):
        return [x for x in obj if isinstance(x, dict)]
    return None

def normalize_zh(s: str) -> str:
    s = unicodedata.normalize("NFKC", s)
    s = re.sub(r"\s+", "", s)
    s = re.sub(r"[，。、“”‘’？！：；,.!?、\"'()（）\-——…]+", "", s)
    return s
def is_too_similar_zh(new_inp: str, existing_norm_inputs: set, existing_raw_inputs: List[str],
                      jaccard_thr: float = 0.9) -> bool:
    norm_new = normalize_zh(new_inp)
    if not norm_new:
        return True
    if norm_new in existing_norm_inputs:
        return True
    new_set = set(norm_new)
    if not new_set:
        return True
    sample_existing = existing_raw_inputs if len(existing_raw_inputs) <= 300 else random.sample(
        existing_raw_inputs, 300
    )
    for s in sample_existing:
        s_norm = normalize_zh(s)
        if not s_norm:
            continue
        exist_set = set(s_norm)
        inter = len(new_set & exist_set)
        union = len(new_set | exist_set)
        if union == 0:
            continue
        if inter / union >= jaccard_thr:
            return True
    return False


def looks_like_non_uyghur_arabic(s: str) -> bool:
    if not isinstance(s, str):
        return True
    s = s.strip()
    if not s:
        return True
    if ARABIC_CHAR_PATTERN.search(s):
        return False

    if re.search(r"[\u4e00-\u9fff]", s):
        return True
    letters = re.findall(r"[A-Za-z]", s)
    if letters:
        no_space = re.sub(r"\s+", "", s)
        if len(no_space) > 0 and len(letters) / len(no_space) >= 0.3:
            return True
    return False

GEN_TOKENIZER = None
GEN_MODEL = None
GEN_EOS_ID = None

FILTER_TOKENIZER = None
FILTER_MODEL = None
FILTER_EOS_ID = None

TRANS_TOKENIZER = None
TRANS_MODEL = None
TRANS_EOS_ID = None
def _resolve_eos_id(tokenizer, model_config):
    eos_id = getattr(tokenizer, "eos_token_id", None)
    if eos_id is None:
        eos_id = getattr(model_config, "eos_token_id", None)
    if eos_id is None:
        eos_id = getattr(tokenizer, "pad_token_id", None)
    return eos_id
def load_models():
    global GEN_TOKENIZER, GEN_MODEL, GEN_EOS_ID
    global FILTER_TOKENIZER, FILTER_MODEL, FILTER_EOS_ID
    global TRANS_TOKENIZER, TRANS_MODEL, TRANS_EOS_ID

    print("[INFO] 正在加载生成模型 Qwen3-32B ...")
    GEN_TOKENIZER = AutoTokenizer.from_pretrained(GEN_MODEL_PATH, trust_remote_code=True)
    GEN_MODEL = AutoModelForCausalLM.from_pretrained(
        GEN_MODEL_PATH,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        trust_remote_code=True,
    )
    GEN_MODEL.eval()
    GEN_EOS_ID = _resolve_eos_id(GEN_TOKENIZER, GEN_MODEL.config)
    print(f"[INFO] 生成模型加载完毕, eos_token_id={GEN_EOS_ID}。")

    print("[INFO] 正在加载筛选模型 Qwen3-4B-Instruct ...")
    FILTER_TOKENIZER = AutoTokenizer.from_pretrained(FILTER_MODEL_PATH, trust_remote_code=True)
    FILTER_MODEL = AutoModelForCausalLM.from_pretrained(
        FILTER_MODEL_PATH,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        trust_remote_code=True,
    )
    FILTER_MODEL.eval()
    FILTER_EOS_ID = _resolve_eos_id(FILTER_TOKENIZER, FILTER_MODEL.config)
    print(f"[INFO] 筛选模型加载完毕, eos_token_id={FILTER_EOS_ID}。")
    print("[INFO] 正在加载 Hunyuan-MT-7B 翻译模型 ...")
    TRANS_TOKENIZER = AutoTokenizer.from_pretrained(TRANS_MODEL_PATH)
    TRANS_MODEL = AutoModelForCausalLM.from_pretrained(
        TRANS_MODEL_PATH,
        torch_dtype=torch.bfloat16,
        device_map="auto",
    )
    TRANS_MODEL.eval()
    TRANS_EOS_ID = _resolve_eos_id(TRANS_TOKENIZER, TRANS_MODEL.config)
    print(f"[INFO] Hunyuan-MT 翻译模型加载完毕, eos_token_id={TRANS_EOS_ID}。")
@torch.no_grad()
def gen_text(prompt: str, max_new_tokens: int = 1024) -> str:
    inputs = GEN_TOKENIZER(prompt, return_tensors="pt").to(GEN_MODEL.device)
    output_ids = GEN_MODEL.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        do_sample=False,
        eos_token_id=GEN_EOS_ID,
        pad_token_id=GEN_EOS_ID,
    )
    new_tokens = output_ids[0][inputs["input_ids"].shape[1]:]
    text = GEN_TOKENIZER.decode(new_tokens, skip_special_tokens=True)
    return text.strip()
@torch.no_grad()
def translate_zh_to_ug(text: str, max_new_tokens: int = 256) -> str:

    if not isinstance(text, str):
        return ""
    text = text.strip()
    if not text:
        return ""
    user_content = f"把下面的文本翻译成维吾尔语，不要额外解释。\n\n{text}"
    use_chat = hasattr(TRANS_TOKENIZER, "apply_chat_template")
    input_len = None

    if use_chat:
        messages = [{"role": "user", "content": user_content}]
        try:
            input_ids = TRANS_TOKENIZER.apply_chat_template(
                messages,
                tokenize=True,
                add_generation_prompt=True,
                return_tensors="pt",
            )
        except TypeError:
            input_ids = TRANS_TOKENIZER.apply_chat_template(
                messages,
                tokenize=True,
                return_tensors="pt",
            )
        input_ids = input_ids.to(TRANS_MODEL.device)
        input_len = input_ids.shape[1]
        gen_args = {"input_ids": input_ids}
    else:
        enc = TRANS_TOKENIZER(user_content, return_tensors="pt")
        enc = {k: v.to(TRANS_MODEL.device) for k, v in enc.items()}
        input_len = enc["input_ids"].shape[1]
        gen_args = enc

    pad_id = getattr(TRANS_TOKENIZER, "pad_token_id", None)
    if pad_id is None:
        pad_id = TRANS_EOS_ID

    if pad_id is not None:
        output_ids = TRANS_MODEL.generate(
            **gen_args,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=pad_id,
        )
    else:
        output_ids = TRANS_MODEL.generate(
            **gen_args,
            max_new_tokens=max_new_tokens,
            do_sample=False,
        )

    seq = output_ids[0]
    if input_len is not None and seq.shape[0] > input_len:
        new_tokens = seq[input_len:]
    else:
        new_tokens = seq

    out = TRANS_TOKENIZER.decode(new_tokens, skip_special_tokens=True)
    return out.strip()


@torch.no_grad()
def filter_text(prompt: str, max_new_tokens: int = 8) -> str:
    inputs = FILTER_TOKENIZER(prompt, return_tensors="pt").to(FILTER_MODEL.device)
    output_ids = FILTER_MODEL.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        do_sample=False,
        eos_token_id=FILTER_EOS_ID,
        pad_token_id=FILTER_EOS_ID,
    )
    new_tokens = output_ids[0][inputs["input_ids"].shape[1]:]
    text = FILTER_TOKENIZER.decode(new_tokens, skip_special_tokens=True)
    return text.strip()

# ====================== 采样 & 过滤 ======================

def sample_from_list(data: List[Dict], k: int) -> List[Dict]:
    if not data:
        return []
    k_eff = min(k, len(data))
    return random.sample(data, k_eff)


def call_model_generate(examples: List[Dict], num_new: int = BATCH_SIZE) -> List[Dict]:
    ex_objs = [
        {
            "src->tgt": ex.get("src->tgt", DIRECTION),
            "instruction": ex.get("instruction", ""),
            "input": ex.get("input", ""),
        }
        for ex in examples
    ]
    examples_json = json.dumps(ex_objs, ensure_ascii=False, indent=2)
    prompt = PROMPT_GEN_TEMPLATE.format(examples_json=examples_json, num_new=num_new)

    raw = gen_text(prompt, max_new_tokens=1024)

    if DEBUG_SHOW_RAW:
        print("[DEBUG] 本轮模型原始输出（前 2000 字符）：")
        print(raw[:2000])

    parsed = extract_json_array(raw)
    if not isinstance(parsed, list):
        print("[WARN] 生成结果无法解析为 JSON 对象列表。")
        return []

    parsed = [x for x in parsed if isinstance(x, dict)]
    total = len(parsed)
    if total == 0:
        print("[WARN] 提取到 0 个 JSON 对象。")
        return []

    if total > num_new:
        print(f"[WARN] 解析到 {total} 条，按设定只保留前 {num_new} 条，其余丢弃。")
        parsed = parsed[:num_new]
    elif total < num_new:
        print(f"[WARN] 期望 {num_new} 条，实际只有 {total} 条。")

    print(f"[INFO] 模型输出 JSON 条数（截断后）: {len(parsed)}")
    return parsed

def basic_check_chinese_sample(s: Dict) -> bool:
    if not isinstance(s, dict):
        return False
    inst = s.get("instruction", "")
    inp = s.get("input", "")
    if not isinstance(inst, str) or not isinstance(inp, str):
        return False
    inst = inst.strip()
    inp = inp.strip()
    if not inst or not inp:
        return False
    if not (5 <= len(inst) <= 120 and 5 <= len(inp) <= 200):
        return False
    if not re.search(r"[\u4e00-\u9fff]", inp):
        return False
    return True

def basic_check_sample(s: Dict) -> bool:
    for key in ["src->tgt", "instruction", "input", "output"]:
        if key not in s or not isinstance(s[key], str):
            return False
    if s["src->tgt"] != DIRECTION:
        return False
    inp = s["input"].strip()
    out = s["output"].strip()
    if not (5 <= len(inp) <= 200 and 5 <= len(out) <= 300):
        return False
    if looks_like_non_uyghur_arabic(out):
        return False
    return True

def call_filter_model(sample: Dict) -> bool:
    sample_json = json.dumps(sample, ensure_ascii=False, indent=2)
    prompt = PROMPT_FILTER_TEMPLATE.format(sample_json=sample_json)
    resp = filter_text(prompt)
    resp_up = resp.strip().upper()
    if resp_up.startswith("OK"):
        return True
    if resp_up.startswith("REJECT"):
        return False
    return False


def assign_new_ids(pool: List[Dict], new_samples: List[Dict]) -> None:
    max_id = 0
    for ex in pool:
        try:
            v = ex.get("id")
            if v is None:
                continue
            max_id = max(max_id, int(v))
        except Exception:
            continue
    next_id = max_id + 1
    for s in new_samples:
        data = {
            "id": f"{next_id:05d}",
            "src->tgt": s.get("src->tgt", DIRECTION),
            "instruction": s.get("instruction", "").strip(),
            "input": s.get("input", "").strip(),
            "output": s.get("output", "").strip(),
        }
        next_id += 1
        pool.append(data)


def print_progress(current_size: int, target_size: int):
    pct = current_size / target_size * 100.0
    bar_len = 30
    filled = int(bar_len * current_size / target_size)
    bar = "█" * filled + "-" * (bar_len - filled)
    print(f"[PROGRESS] |{bar}| {current_size} / {target_size} ({pct:.2f}%)")

# ====================== pool 清理 ======================

def clean_pool_non_uyghur(pool: List[Dict]) -> List[Dict]:
    new_pool = []
    dropped = 0
    for ex in pool:
        out = ex.get("output", "")
        if isinstance(out, str) and out.strip():
            if looks_like_non_uyghur_arabic(out):
                dropped += 1
                continue
        new_pool.append(ex)
    if dropped > 0:
        print(f"[CLEAN] 从已有 pool 中剔除了 {dropped} 条疑似英文/非阿文 output 的样本。")
    return new_pool

# ====================== 主流程 ======================

def main():
    random.seed(42)

    if not SEED_PATH.exists():
        raise FileNotFoundError(f"种子文件不存在: {SEED_PATH}")

    load_models()

    seed = load_json(SEED_PATH)
    print(f"[INFO] 读取种子共 {len(seed)} 条。")

    if POOL_PATH.exists():
        pool = load_json(POOL_PATH)
        if not pool:
            pool = list(seed)
            print(f"[WARN] pool 文件为空, 已用种子重新初始化, 当前大小 {len(pool)}。")
        else:
            print(f"[INFO] 发现已有 pool 文件, 当前大小: {len(pool)}。")
        pool = clean_pool_non_uyghur(pool)
    else:
        pool = list(seed)
        print(f"[INFO] 初始化 pool: 直接使用种子, 当前大小 {len(pool)}。")

    existing_norm_inputs = set()
    existing_raw_inputs: List[str] = []
    for ex in pool:
        inp = ex.get("input", "")
        if not isinstance(inp, str):
            continue
        inp = inp.strip()
        if not inp:
            continue
        existing_raw_inputs.append(inp)
        existing_norm_inputs.add(normalize_zh(inp))

    save_json(POOL_PATH, pool)
    print(f"[INFO] 清理后 pool 大小: {len(pool)}，已写回 {POOL_PATH}。")

    step = 0
    while len(pool) < TARGET_SIZE:
        step += 1
        print("\n" + "=" * 60)
        print(f"[STEP] 第 {step} 轮迭代, 当前 pool 大小: {len(pool)}")

        examples = sample_from_list(pool if pool else seed, 4)
        if not examples:
            print("[WARN] 本轮没有可用的示例, 直接跳过。")
            continue

        candidates = call_model_generate(examples, num_new=BATCH_SIZE)
        if not candidates:
            print("[WARN] 本轮生成为空, 跳过。")
            print_progress(len(pool), TARGET_SIZE)
            continue

        tmp_inputs: List[Dict] = []
        for c in candidates:
            if not basic_check_chinese_sample(c):
                continue
            inp = c.get("input", "")
            if not isinstance(inp, str):
                continue
            inp = inp.strip()
            if not inp:
                continue
            if is_too_similar_zh(inp, existing_norm_inputs, existing_raw_inputs):
                continue
            tmp_inputs.append({
                "src->tgt": DIRECTION,
                "instruction": c.get("instruction", "").strip(),
                "input": inp,
            })

        print(f"[INFO] 通过基本结构+去重检查的中文样本数: {len(tmp_inputs)}")
        if not tmp_inputs:
            print("[WARN] 本轮中文样本全部被过滤掉。")
            print_progress(len(pool), TARGET_SIZE)
            continue

        translated_candidates: List[Dict] = []
        for idx, c in enumerate(tmp_inputs, start=1):
            zh_inp = c["input"].strip()
            ug_out = translate_zh_to_ug(zh_inp)

            print(f"[HUNYUAN] 样本 {idx}:")
            print(f"  输入(zh): {zh_inp[:150]}")
            print(f"  输出(ug): {ug_out[:150]}")

            if not ug_out:
                print("  [HUNYUAN] 输出为空，丢弃。")
                continue
            if looks_like_non_uyghur_arabic(ug_out):
                print("  [HUNYUAN] 输出疑似非阿文（英文/中文），已丢弃。")
                continue

            full_sample = {
                "src->tgt": DIRECTION,
                "instruction": c["instruction"],
                "input": zh_inp,
                "output": ug_out.strip(),
            }
            if not basic_check_sample(full_sample):
                print("  [HUNYUAN] 长度/结构检查未通过，已丢弃。")
                continue

            translated_candidates.append(full_sample)

        print(f"[INFO] 完成 Hunyuan 翻译并通过长度/脚本检查的样本数: {len(translated_candidates)}")
        if not translated_candidates:
            print("[WARN] 本轮翻译后样本全部被过滤掉。")
            print_progress(len(pool), TARGET_SIZE)
            continue

        accepted: List[Dict] = []
        for c in translated_candidates:
            if call_filter_model(c):
                accepted.append(c)

        print(f"[INFO] 本轮经筛选模型保留: {len(accepted)} 条。")
        if not accepted:
            print("[WARN] 本轮没有新的样本通过筛选, pool 大小不变。")
            print_progress(len(pool), TARGET_SIZE)
            continue

        assign_new_ids(pool, accepted)
        save_json(POOL_PATH, pool)

        for s in accepted:
            inp = s.get("input", "")
            if not isinstance(inp, str):
                continue
            inp = inp.strip()
            if not inp:
                continue
            existing_raw_inputs.append(inp)
            existing_norm_inputs.add(normalize_zh(inp))

        print(f"[OK] 本轮已将 {len(accepted)} 条样本加入 pool, 当前大小: {len(pool)}")
        print_progress(len(pool), TARGET_SIZE)

    print("\n[DONE] 已达到目标大小, 结束 Self-Instruct 过程。")
    print(f"[FINAL] pool 文件: {POOL_PATH} | 总条数: {len(pool)}")

if __name__ == "__main__":
    main()